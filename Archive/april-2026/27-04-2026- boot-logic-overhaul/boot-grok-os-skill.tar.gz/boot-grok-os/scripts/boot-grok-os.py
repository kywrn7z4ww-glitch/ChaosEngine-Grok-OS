#!/usr/bin/env python3
"""
boot-grok-os.py — Enhanced ChaosEngine Grok OS Bootstrapper
v2.1 — SHA-verified tree + on-demand lazy sync + chain fire
"""

import os
import json
import urllib.request
import urllib.error
from pathlib import Path
import subprocess

REPO_OWNER = "kywrn7z4ww-glitch"
REPO_NAME = "ChaosEngine-Grok-OS"
BRANCH = "main"
LOCAL_ROOT = Path("/opt/grok-os/ROOT")
CACHE_DIR = Path("/opt/grok-os/.cache")
LAST_SHA_FILE = CACHE_DIR / "last_tree_sha.txt"

API_COMMIT_URL = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/commits/{BRANCH}"
API_TREE_URL = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/git/trees/{BRANCH}?recursive=1"
RAW_BASE = f"https://raw.githubusercontent.com/{REPO_OWNER}/{REPO_NAME}/{BRANCH}/"

def get_latest_sha():
    """Fetch the latest commit SHA for the branch"""
    try:
        with urllib.request.urlopen(API_COMMIT_URL, timeout=10) as resp:
            data = json.loads(resp.read().decode())
            return data.get("sha", "")
    except Exception as e:
        print(f"[WARN] Could not fetch latest SHA: {e}")
        return ""

def is_tree_current() -> bool:
    """Check if we already have the latest tree"""
    if not LAST_SHA_FILE.exists():
        return False
    cached_sha = LAST_SHA_FILE.read_text().strip()
    latest_sha = get_latest_sha()
    if not latest_sha:
        return False
    return cached_sha == latest_sha

def update_tree_sha(sha: str):
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    LAST_SHA_FILE.write_text(sha)

def fetch_file_on_demand(rel_path: str) -> bool:
    """On-demand fetch for missing files during runtime"""
    if not rel_path.startswith("ROOT/"):
        rel_path = f"ROOT/{rel_path}"
    
    url = RAW_BASE + rel_path.replace("ROOT/", "", 1)
    local_path = LOCAL_ROOT / rel_path.replace("ROOT/", "", 1)
    local_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        with urllib.request.urlopen(url, timeout=10) as resp:
            content = resp.read()
        local_path.write_bytes(content)
        print(f"[ON-DEMAND] Fetched & mirrored: {rel_path}")
        return True
    except Exception as e:
        print(f"[ON-DEMAND] Failed to fetch {rel_path}: {e}")
        return False

def fetch_tree():
    print("[boot-grok-os] Fetching live tree + SHA verification...")
    try:
        latest_sha = get_latest_sha()
        if latest_sha:
            print(f"  Latest commit SHA: {latest_sha[:12]}...")

        with urllib.request.urlopen(API_TREE_URL, timeout=15) as resp:
            data = json.loads(resp.read().decode())
        
        if latest_sha:
            update_tree_sha(latest_sha)
        
        return [item["path"] for item in data.get("tree", []) if item["path"].startswith("ROOT/")]
    except Exception as e:
        print(f"[ERROR] Tree fetch failed: {e}")
        return []

def pull_file(rel_path: str):
    url = RAW_BASE + rel_path.replace("ROOT/", "", 1)
    local_path = LOCAL_ROOT / rel_path.replace("ROOT/", "", 1)
    local_path.parent.mkdir(parents=True, exist_ok=True)
    
    try:
        with urllib.request.urlopen(url, timeout=10) as resp:
            content = resp.read()
        local_path.write_bytes(content)
        print(f"  ✅ {rel_path}")
        return True
    except urllib.error.HTTPError as e:
        if e.code == 404:
            print(f"  ⚠️ 404 (skipped): {rel_path}")
        else:
            print(f"  ❌ {rel_path}: {e}")
        return False
    except Exception as e:
        print(f"  ❌ {rel_path}: {e}")
        return False

def pull_all():
    paths = fetch_tree()
    if not paths:
        return 0

    valid_paths = [p for p in paths if not p.lower().endswith("readme.md")]
    pulled = 0
    for p in sorted(valid_paths):
        if pull_file(p):
            pulled += 1
    return pulled

def main():
    print("=== BOOT GROK OS v2.1 (SHA-verified) ===")
    print("Features: SHA verification + Full mirror + On-demand lazy sync")
    print("Poison protection: ACTIVE (all README.md ignored)\n")

    if is_tree_current():
        print("[FAST-PATH] Local tree matches latest commit SHA — skipping full pull.")
        print("  (Still running chain-fire on existing mirror)\n")
    else:
        print("[Phase 1] Full mirror of ROOT/ (SHA changed or first run)...")
        count = pull_all()
        print(f"Mirrored {count} files.\n")

    print("[Phase 2] Chain-firing 1_GrokOS.py ...")
    bootloader = LOCAL_ROOT / "1_GrokOS.py"
    if bootloader.exists():
        os.chdir(LOCAL_ROOT)
        try:
            subprocess.run(["python3", "1_GrokOS.py"], timeout=60)
        except Exception as e:
            print(f"Bootloader error: {e}")
    else:
        print("Bootloader not found — attempting on-demand fetch...")
        fetch_file_on_demand("1_GrokOS.py")

    print("\n=== GROK OS ONLINE ===")
    print("SHA-verified sync active. Future boots will be faster when tree is unchanged.")

if __name__ == "__main__":
    main()
