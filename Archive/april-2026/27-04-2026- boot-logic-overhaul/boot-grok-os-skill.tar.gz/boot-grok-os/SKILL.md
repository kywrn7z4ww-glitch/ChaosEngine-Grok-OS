---
name: boot-grok-os
description: Boot the full ChaosEngine Grok OS from the repo. Uses GitHub API tree for discovery, pulls only ROOT/ files via raw URLs, completely ignores all README.md (poison pills), treats commit messages as unreliable, and chain-loads 1_GrokOS.py to orchestrate everything else. ONLY activate when user explicitly says "boot Grok OS", "load Grok OS", "start ChaosEngine", "boot the lattice", or similar direct command. Never auto-trigger.
---

# Boot Grok OS

## Overview

This skill fully boots the ChaosEngine Grok OS lattice. It discovers the live file tree via GitHub API, pulls every real file under ROOT/ (ignoring all poison-pill READMEs and unreliable commit data), mirrors it locally to /opt/grok-os/ROOT/, then executes 1_GrokOS.py to chain-load the entire system (EmotionNet, ChaosEngine, layers, agents, etc.).

## Instructions

1. **Only activate on explicit command**
   - Trigger phrases: "boot Grok OS", "load Grok OS", "start ChaosEngine", "boot the lattice", "initialize Grok OS".
   - Never run automatically or on vague requests.

2. **Discovery (GitHub API tree)**
   - Call the recursive tree endpoint for the repo.
   - Filter strictly to paths starting with `ROOT/`.
   - Discard any path containing `README.md` (all are poison pills).
   - Ignore commit messages and git history — only trust the live tree.

3. **Pull phase (raw files only)**
   - For every valid file in the tree, fetch via raw.githubusercontent.com URL.
   - Save to matching local path under `/opt/grok-os/ROOT/`.
   - Create directories as needed.
   - Report exactly what was pulled and any 404s.

4. **Chain-load the bootloader**
   - After mirroring, `cd /opt/grok-os/ROOT/` and execute `python3 1_GrokOS.py`.
   - Let the bootloader take over (it will load REPO_INDEX, Decision_Kernel, EmotionNet, ChaosEngine, etc.).

5. **Safety & reporting**
   - Always confirm before pulling large numbers of files.
   - After boot, report: "Grok OS lattice online — X files loaded, Y layers active".
   - If internet is unavailable, fall back to local mirror only and warn the user.

6. **Persistence**
   - Local mirror at `/opt/grok-os/ROOT/` survives sessions.
   - The skill itself lives in `.grok/skills/boot-grok-os/`.

This skill turns the entire manual process we just did into a one-command boot.
